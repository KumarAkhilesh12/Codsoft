package com.akhilesh.alarmclock

class DestinationActivity {
}