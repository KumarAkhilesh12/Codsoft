# Quotify - Simple Quotes App 

- This app shows the use of ViewModel and ViewModelFactory Concept
- Learn about ViewModels by creating this simple app.
- App uses static data provided as JSON.

You can watch the tutorial video covering everything step by step - 
https://www.youtube.com/watch?v=HfkyXuZdD_c

With ❤️ from [CheezyCode](https://www.youtube.com/channel/UCOknqk-MSOCf3SANW8Wumfg)
