package com.akhilesh.quotes

data class Quote(val text: String, val author: String )